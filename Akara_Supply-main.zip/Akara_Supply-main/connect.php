<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "akara_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
?>